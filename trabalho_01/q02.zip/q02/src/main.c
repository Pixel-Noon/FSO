#include <stdio.h>
#include "io_functions.h"

int main(int argc, char const *argv[]){
	start(argc, argv);

	return 0;
}
